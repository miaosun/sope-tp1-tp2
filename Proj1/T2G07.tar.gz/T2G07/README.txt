Sistemas Operativos, 2ºAno MIEIC 2012/13, FEUP

Jorge Reis 080509053
Miao Sun 080509162

Passos necessarios:
Para compilar o programa completo, basta executar o comando "make".
Para compilar apenas os ficheiros de backup, executa-se o comando "make backup",
e para compilar os ficheiros de restore, executa-se o comando "make restore".

Posteriormente, para executar, executa-se os comandos:

BACKUP: bckp dir1 dir2 dt &
	dir1: directório a monitorizar
	dir2: directório para onde fazer backup
	dt: intervalo entre backups incrementais

RESTORE: rstr dir2 dir3
	 dir2: directório onde estão as cópias de segurança
	 dir3: directório para onde realizar a recuperação
